package Starting;
import EasyInvoicing.AlertBox;
import EasyInvoicing.Company;
import EasyInvoicing.DBConnections;
import EasyInvoicing.Queries;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;


public class Controller implements Initializable {

    @FXML
    private TableView<Company> CompanyTable;
    @FXML
    private TableColumn<Company,String> TableName;
     public static ObservableList<Company> companiess = FXCollections.observableArrayList();

     private void CompanySet()  {

        Connection conn= DBConnections.getConnection();
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery("select CompId,CompName from company");
            System.out.println("Done");
            companiess.clear();
            while (rs.next()) {
                companiess.add(new Company(rs.getInt("CompID"), rs.getString("CompName")));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        TableName.setCellValueFactory(new PropertyValueFactory<>("CompName"));
        CompanyTable.setItems(companiess);
        conn=null;
    }
    @FXML
    void onAddCompany() throws IOException {

        Parent  root;
        root = FXMLLoader.load(getClass().getResource("AddCompany.fxml"));
        EasyInvoicing.Controller secondController=new EasyInvoicing.Controller();
        //secondController.setCompany(CompanyTable.getSelectionModel().getSelectedItem());
        Stage stage=new Stage();
        stage.setScene(new Scene(root, 1280 , 720));
        stage.show();
    }

    @FXML
    JFXButton SelectCompany;
    @FXML
    JFXButton AddCompany;
    @FXML
    void onSelectCompany(ActionEvent event) throws IOException {
        if(CompanyTable.getSelectionModel().isEmpty())
        {
            AlertBox.display("Error", "Please select Company first ");
        }
        else {
            Parent root = FXMLLoader.load(getClass().getResource("./../EasyInvoicing/Main.fxml"));
            EasyInvoicing.Controller secondController = new EasyInvoicing.Controller();
            secondController.setCompany(CompanyTable.getSelectionModel().getSelectedItem());
            Stage stage = new Stage();
            stage.setScene(new Scene(root, 1280, 720));
            stage.show();
        }
    }


    @FXML
    JFXTextField TextCompName;
    @FXML
    JFXTextField TextCompAddress;
    @FXML
    JFXTextField TextCompCity;
    @FXML
    JFXTextField TextCompState;
    @FXML
    JFXTextField TextCompZipCode;
    @FXML
    JFXTextField TextCompCountry;
    @FXML
    JFXTextField TextCompGSTTin;
    @FXML
    JFXTextField TextCompGSTStateCode;
    @FXML
    JFXTextField TextCompBankAcNo;
    @FXML
    JFXTextField TextCompBankName;
    @FXML
    JFXTextField TextCompBankBranch;
    @FXML
    JFXTextField TextCompBankIFSC;

@FXML
JFXButton CompanySaveButton;

    @FXML
    void SaveCompany(ActionEvent e){
        boolean alert=false;
        String CompName=TextCompName.getText().toString();
        Connection conn=DBConnections.getConnection();
        try {
            PreparedStatement stmt = conn.prepareStatement("select CompName from company where CompName=?");
            stmt.setString(1, CompName);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                alert = true;
            }
            if (alert) {
                AlertBox.display("Error", "Company Already Exist");
            } else {

                new Queries().setCompanyData(new Company(0, TextCompName.getText().toString(), TextCompAddress.getText().toString(), TextCompCity.getText().toString(), TextCompState.getText().toString(), TextCompZipCode.getText().toString(), TextCompCountry.getText().toString(), TextCompGSTTin.getText().toString(), TextCompGSTStateCode.getText().toString(), TextCompBankAcNo.getText().toString(), TextCompBankName.getText().toString(), TextCompBankBranch.getText().toString(), TextCompBankIFSC.getText().toString(), false, 0));
                companiess.add(new Company(0, TextCompName.getText().toString(), TextCompAddress.getText().toString(), TextCompCity.getText().toString(), TextCompState.getText().toString(), TextCompZipCode.getText().toString(), TextCompCountry.getText().toString(), TextCompGSTTin.getText().toString(), TextCompGSTStateCode.getText().toString(), TextCompBankAcNo.getText().toString(), TextCompBankName.getText().toString(), TextCompBankBranch.getText().toString(), TextCompBankIFSC.getText().toString(), false, 0));
                AlertBox.display("Saved", "Company's Data Has Been Saved");

            }
        }
        catch (SQLException Error)
        {
            AlertBox.display("Error", "Can't able to add New Company");
        }
       // CompanySet();

    }

    boolean b=true;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
            CompanySet();
    }

}
