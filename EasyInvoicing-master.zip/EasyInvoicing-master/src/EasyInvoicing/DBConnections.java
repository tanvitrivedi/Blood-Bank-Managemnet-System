package EasyInvoicing;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnections{
    static Connection conn=null;
    public static Connection getConnection()
    {
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost/", "root", "");
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("create database if not exists EasyInvoicing");
            stmt.executeUpdate("use EasyInvoicing");
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS Company(CompId bigint NOT NULL AUTO_INCREMENT,CompName varchar(200) NOT NULL,CompAddress varchar(200),CompCity varchar(150),CompState varchar(150),CompZipCode varchar(8),CompContry varchar(100),CompGSTTin varchar(15),CompGSTStateCode varchar(2),CompBankAcNo varchar(18),CompBankName varchar(200),CompBankBranch varchar(100),CompBankIFSC varchar(11),CompLetterHeadCheck Boolean,CompLetterHead DOUBLE(3,2),PRIMARY KEY(CompId))");
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS customers(CustId bigint NOT NULL AUTO_INCREMENT,CustName varchar(50) NOT NULL ,CustGstTin varchar(15),CustGstStateCode varchar(4),CustMobile varchar(10) NOT NULL,CustAMobile varchar(10),CustAddress varchar(200),CustCity varchar(100),CustState varchar(100),CustZipCode varchar(8),CompId bigint NOT NULL,UNIQUE (CustId,CustGstTin),FOREIGN KEY (CompId)REFERENCES Company(CompId),PRIMARY KEY(custId))");
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS Product(ProductId bigint NOT NULL AUTO_INCREMENT,ProductName varchar(200),ProductUnit varchar(100),ProductHSNC varchar(10),CompId bigint NOT NULL,FOREIGN KEY (CompId)REFERENCES Company(CompId),PRIMARY KEY(ProductID))");
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS Invoice(INVId bigint NOT NULL AUTO_INCREMENT,CompId bigint,CustId bigint,InvoiceDate DATE,InvoiceAmount DOUBLE(20,2),InvoiceDiscount Double(20,2),InvoiceCGST Double(20,2),InvoiceSGST Double(20,2),InvoiceIGST DOUBLE (20,2),InvoiceGrandTotal DOUBLE(20,2),SA boolean,Foreign key (CompId) REFERENCES Company(CompId),Foreign key (CustId) references customers(CustId),PRIMARY KEY(INVId))");
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS InvoiceIteam(INVId bigint not null,ProductId bigint not null,Quantity int,Price Double(20,2),Foreign key (INVId) references Invoice(INVId),Foreign Key (ProductId) references Product(ProductId))");
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS ShippingAddress(INVId bigint NOT NULL,CustId bigint NOT NULL,Address varchar(200),City varchar(100),State varchar(100),ZipCode varchar(8),Foreign key (INVId) references Invoice(INVId),Foreign key (CustId) references customers(CustId))");
        }catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }
}
