package EasyInvoicing;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class BillingInformation {
   private Integer INVId;
    private String CustName;
    private String InvoiceDate;
    private Double Amount;
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-M-yyyy");
    public BillingInformation(Integer INVId, String custName, String invoiceDate, Double amount) {
        this.INVId = INVId;
        CustName = custName;
        InvoiceDate = invoiceDate;
        Amount = amount;
    }

    public Integer getINVId() {
        return INVId;
    }

    public void setINVId(Integer INVId) {
        this.INVId = INVId;
    }

    public String getCustName() {
        return CustName;
    }

    public void setCustName(String custName) {
        CustName = custName;
    }

    public String getInvoiceDate() {
        return InvoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        InvoiceDate = invoiceDate;
    }

    public Double getAmount() {
        return Amount;
    }

    public void setAmount(Double amount) {
        Amount = amount;
    }
}
