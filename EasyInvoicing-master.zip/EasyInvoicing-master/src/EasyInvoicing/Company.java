package EasyInvoicing;

public class Company {
    Integer CompId;
    String CompName;
    String CompAddress;
    String CompCity;
    String CompState;
    String CompZipCode;
    String CompCountry;
    String CompGSTTin;
    String CompGSTStateCode;
    String CompBankAcNo;
    String CompBankName;
    String CompBankBranch;
    String CompBankIFSC;
    boolean CompLetterHeadCheck;
    double CompLetterHead;

    public Company(int compId, String compName) {
        CompId = compId;
        CompName = compName;
    }

    public Company(int compId, String compName, String compAddress, String compCity, String compState, String compZipCode, String compCountry, String compGSTTin, String compGSTStateCode, String compBankAcNo, String compBankName, String compBankBranch, String compBankIFSC, boolean compLetterHeadCheck, double compLetterHead) {
        CompId = compId;
        CompName = compName;
        CompAddress = compAddress;
        CompCity = compCity;
        CompState = compState;
        CompZipCode = compZipCode;
        CompCountry = compCountry;
        CompGSTTin = compGSTTin;
        CompGSTStateCode = compGSTStateCode;
        CompBankAcNo = compBankAcNo;
        CompBankName = compBankName;
        CompBankBranch = compBankBranch;
        CompBankIFSC = compBankIFSC;
        CompLetterHeadCheck = compLetterHeadCheck;
        CompLetterHead = compLetterHead;
    }

    public Integer getCompId() {
        return CompId;
    }

    public void setCompId(int compId) {
        CompId = compId;
    }

    public String getCompName() {
        return CompName;
    }

    public void setCompName(String compName) {
        CompName = compName;
    }

    public String getCompAddress() {
        return CompAddress;
    }

    public void setCompAddress(String compAddress) {
        CompAddress = compAddress;
    }

    public String getCompCity() {
        return CompCity;
    }

    public void setCompCity(String compCity) {
        CompCity = compCity;
    }

    public String getCompState() {
        return CompState;
    }

    public void setCompState(String compState) {
        CompState = compState;
    }

    public String getCompZipCode() {
        return CompZipCode;
    }

    public void setCompZipCode(String compZipCode) {
        CompZipCode = compZipCode;
    }

    public String getCompCountry() {
        return CompCountry;
    }

    public void setCompCountry(String compCountry) {
        CompCountry = compCountry;
    }

    public String getCompGSTTin() {
        return CompGSTTin;
    }

    public void setCompGSTTin(String compGSTTin) {
        CompGSTTin = compGSTTin;
    }

    public String getCompGSTStateCode() {
        return CompGSTStateCode;
    }

    public void setCompGSTStateCode(String compGSTStateCode) {
        CompGSTStateCode = compGSTStateCode;
    }

    public String getCompBankAcNo() {
        return CompBankAcNo;
    }

    public void setCompBankAcNo(String compBankAcNo) {
        CompBankAcNo = compBankAcNo;
    }

    public String getCompBankName() {
        return CompBankName;
    }

    public void setCompBankName(String compBankName) {
        CompBankName = compBankName;
    }

    public String getCompBankBranch() {
        return CompBankBranch;
    }

    public void setCompBankBranch(String compBankBranch) {
        CompBankBranch = compBankBranch;
    }

    public String getCompBankIFSC() {
        return CompBankIFSC;
    }

    public void setCompBankIFSC(String compBankIFSC) {
        CompBankIFSC = compBankIFSC;
    }

    public boolean isCompLetterHeadCheck() {
        return CompLetterHeadCheck;
    }

    public void setCompLetterHeadCheck(boolean compLetterHeadCheck) {
        CompLetterHeadCheck = compLetterHeadCheck;
    }

    public double getCompLetterHead() {
        return CompLetterHead;
    }

    public void setCompLetterHead(double compLetterHead) {
        CompLetterHead = compLetterHead;
    }
    //changesmade in
}
//in master