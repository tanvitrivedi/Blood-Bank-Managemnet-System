package EasyInvoicing;

import javafx.scene.control.DatePicker;
import org.omg.PortableInterceptor.INACTIVE;

import java.time.LocalDate;
import java.util.Date;

public class FinalInvoice {
    Integer InvoiceNumber;
    Integer CompId;
    Integer CustId;
    LocalDate InvoiceDate;
    Double InvoiceAmount;
    Double InvoiceDiscount;
    Double InvoiceCGST;
    Double InvoiceSGST;
    Double InvoiceIGST;
    Double InvoiceGrandTotal;

    public FinalInvoice(Integer invoiceNumber, Integer compId, Integer custId, LocalDate invoiceDate, Double invoiceAmount, Double invoiceDiscount, Double invoiceCGST, Double invoiceSGST, Double invoiceIGST, Double invoiceGrandTotal) {
        InvoiceNumber = invoiceNumber;
        CompId = compId;
        CustId = custId;
        InvoiceDate = invoiceDate;
        InvoiceAmount = invoiceAmount;
        InvoiceDiscount = invoiceDiscount;
        InvoiceCGST = invoiceCGST;
        InvoiceSGST = invoiceSGST;
        InvoiceIGST = invoiceIGST;
        InvoiceGrandTotal = invoiceGrandTotal;
    }

    public Integer getInvoiceNumber() {
        return InvoiceNumber;
    }

    public void setInvoiceNumber(Integer invoiceNumber) {
        InvoiceNumber = invoiceNumber;
    }

    public Integer getCompId() {
        return CompId;
    }

    public void setCompId(Integer compId) {
        CompId = compId;
    }

    public Integer getCustId() {
        return CustId;
    }

    public void setCustId(Integer custId) {
        CustId = custId;
    }

    public LocalDate getInvoiceDate() {
        return InvoiceDate;
    }

    public void setInvoiceDate(LocalDate invoiceDate) {
        InvoiceDate = invoiceDate;
    }

    public Double getInvoiceAmount() {
        return InvoiceAmount;
    }

    public void setInvoiceAmount(Double invoiceAmount) {
        InvoiceAmount = invoiceAmount;
    }

    public Double getInvoiceDiscount() {
        return InvoiceDiscount;
    }

    public void setInvoiceDiscount(Double invoiceDiscount) {
        InvoiceDiscount = invoiceDiscount;
    }

    public Double getInvoiceCGST() {
        return InvoiceCGST;
    }

    public void setInvoiceCGST(Double invoiceCGST) {
        InvoiceCGST = invoiceCGST;
    }

    public Double getInvoiceSGST() {
        return InvoiceSGST;
    }

    public void setInvoiceSGST(Double invoiceSGST) {
        InvoiceSGST = invoiceSGST;
    }

    public Double getInvoiceIGST() {
        return InvoiceIGST;
    }

    public void setInvoiceIGST(Double invoiceIGST) {
        InvoiceIGST = invoiceIGST;
    }

    public Double getInvoiceGrandTotal() {
        return InvoiceGrandTotal;
    }

    public void setInvoiceGrandTotal(Double invoiceGrandTotal) {
        InvoiceGrandTotal = invoiceGrandTotal;
    }
}
