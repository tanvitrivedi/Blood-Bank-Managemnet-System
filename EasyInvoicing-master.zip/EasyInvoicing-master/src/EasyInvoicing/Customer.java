package EasyInvoicing;

public class Customer {
    Integer CustId;
    String CustName;
    String CustGstTin;
    String CustGstStateCode;
    String CustMobile;
    String CustAMobile;
    String CustAddress;
    String CustCity;
    String CustState;
    String CustZipCode;
    Integer  CompId;
    public Customer() {

    }

    @Override
    public String toString() {
        return CustName;
    }

    public Customer(int custId, String custName, String custGstTin, String custGstStateCode, String custMobile, String custAMobile, String custAddress, String custCity, String custState, String custZipCode, int compId) {
        CustId = custId;
        CustName = custName;
        CustGstTin = custGstTin;
        CustGstStateCode = custGstStateCode;
        CustMobile = custMobile;
        CustAMobile = custAMobile;
        CustAddress = custAddress;
        CustCity = custCity;
        CustState = custState;
        CustZipCode = custZipCode;
        CompId = compId;
    }

    public int getCustId() {
        return CustId;
    }

    public void setCustId(int custId) {
        CustId = custId;
    }

    public String getCustName() {
        return CustName;
    }

    public void setCustName(String custName) {
        CustName = custName;
    }

    public String getCustGstTin() {
        return CustGstTin;
    }

    public void setCustGstTin(String custGstTin) {
        CustGstTin = custGstTin;
    }

    public String getCustGstStateCode() {
        return CustGstStateCode;
    }

    public void setCustGstStateCode(String custGstStateCode) {
        CustGstStateCode = custGstStateCode;
    }

    public String getCustMobile() {
        return CustMobile;
    }

    public void setCustMobile(String custMobile) {
        CustMobile = custMobile;
    }

    public String getCustAMobile() {
        return CustAMobile;
    }

    public void setCustAMobile(String custAMobile) {
        CustAMobile = custAMobile;
    }

    public String getCustAddress() {
        return CustAddress;
    }

    public void setCustAddress(String custAddress) {
        CustAddress = custAddress;
    }

    public String getCustCity() {
        return CustCity;
    }

    public void setCustCity(String custCity) {
        CustCity = custCity;
    }

    public String getCustState() {
        return CustState;
    }

    public void setCustState(String custState) {
        CustState = custState;
    }

    public String getCustZipCode() {
        return CustZipCode;
    }

    public void setCustZipCode(String custZipCode) {
        CustZipCode = custZipCode;
    }

    public int getCompId() {
        return CompId;
    }

    public void setCompId(int compId) {
        CompId = compId;
    }
}