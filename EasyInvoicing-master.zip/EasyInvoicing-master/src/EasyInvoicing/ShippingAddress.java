package EasyInvoicing;

public class ShippingAddress{
    int INVId;
    int Custid;
    String SAAddress;
    String SACity;
    String SAState;
    String SAZipCode;

    public ShippingAddress(int INVId, int custid, String SAAddress, String SACity, String SAState, String SAZipCode) {
        this.INVId = INVId;
        Custid = custid;
        this.SAAddress = SAAddress;
        this.SACity = SACity;
        this.SAState = SAState;
        this.SAZipCode = SAZipCode;
    }

    public int getINVId() {
        return INVId;
    }

    public void setINVId(int INVId) {
        this.INVId = INVId;
    }

    public int getCustid() {
        return Custid;
    }

    public void setCustid(int custid) {
        Custid = custid;
    }

    public String getSAAddress() {
        return SAAddress;
    }

    public void setSAAddress(String SAAddress) {
        this.SAAddress = SAAddress;
    }

    public String getSACity() {
        return SACity;
    }

    public void setSACity(String SACity) {
        this.SACity = SACity;
    }

    public String getSAState() {
        return SAState;
    }

    public void setSAState(String SAState) {
        this.SAState = SAState;
    }

    public String getSAZipCode() {
        return SAZipCode;
    }

    public void setSAZipCode(String SAZipCode) {
        this.SAZipCode = SAZipCode;
    }
}
