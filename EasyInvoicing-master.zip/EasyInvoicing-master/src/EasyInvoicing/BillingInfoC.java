package EasyInvoicing;

import com.jfoenix.controls.JFXTextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class BillingInfoC implements Initializable {
    static public Integer InvoiceNumber;

    @FXML
    private JFXTextField TextInvoiceNumber;

    @FXML
    private JFXTextField InvoiceAmount;

    @FXML
    private JFXTextField InvoiceCGST;

    @FXML
    private JFXTextField InvoiceSGST;

    @FXML
    private JFXTextField InvoiceGrandTotal;

    @FXML
    private JFXTextField InvoiceDiscount;

    @FXML
    private JFXTextField CustName;

    @FXML
    private JFXTextField InvoiceDate;

    static Integer CompId;
    public Integer getInvoiceNumber() {
        return InvoiceNumber;
    }

    public void setInvoiceData(Integer invoiceNumber,Integer compId) {

        InvoiceNumber = invoiceNumber;
        CompId=compId;
    }

    public Integer getCompId() {
        return CompId;
    }

    public void setCompId(Integer compId) {
        CompId = compId;
    }

    ObservableList<InvoiceProduct> invoiceProducts= FXCollections.observableArrayList();
    /*static FinalInvoice finalInvoice;

    public static FinalInvoice getFinalInvoice() {
        return finalInvoice;
    }
    public static void setFinalInvoice(FinalInvoice finalInvoice) {
        BillingInfoC.finalInvoice = finalInvoice;
    }*/
    void setGUIData(FinalInvoice finalInvoice) throws SQLException
    {
        TextInvoiceNumber.setText(finalInvoice.getInvoiceNumber().toString());

        InvoiceAmount.setText(finalInvoice.getInvoiceAmount().toString());


        InvoiceCGST.setText(finalInvoice.getInvoiceCGST().toString());


        InvoiceSGST.setText(finalInvoice.getInvoiceSGST().toString());


        InvoiceGrandTotal.setText(finalInvoice.getInvoiceGrandTotal().toString());


        InvoiceDiscount.setText(finalInvoice.getInvoiceDiscount().toString());

        PreparedStatement stmt=DBConnections.getConnection().prepareStatement("select CustName from customers where CustId=?");
        stmt.setString(1,finalInvoice.getCustId().toString());
        ResultSet rs=stmt.executeQuery();
        while (rs.next())
        {

            CustName.setText(rs.getString("CustName"));
        }
        InvoiceDate.setText(finalInvoice.getInvoiceDate().toString());
    }

    @FXML
    private TableView<InvoiceProduct> TableInvoiceProduct;


    @FXML
    private TableColumn<InvoiceProduct, String> ColumnInvoiceProductName;

    @FXML
    private TableColumn<InvoiceProduct, String> ColumnInvoiceProductHSNC;

    @FXML
    private TableColumn<InvoiceProduct, Integer> ColumnInvoiceProductQuantity;

    @FXML
    private TableColumn<InvoiceProduct,String> ColumnInvoiceProductUnit;

    @FXML
    private TableColumn<InvoiceProduct, Double> ColumnInvoiceProductPrice;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
           //FinalInvoice finalInvoice=new Queries().getFinalInvoice(getInvoiceNumber(),getCompId());
           Connection conn=DBConnections.getConnection();
           PreparedStatement stmt=conn.prepareStatement("select * from invoice where INVId=? and CompId=?");
           stmt.setString(1,getInvoiceNumber().toString());
           stmt.setString(2,getCompId().toString());
           ResultSet rs=stmt.executeQuery();
            FinalInvoice finalInvoice=null;
           while (rs.next())
           {
               finalInvoice=new FinalInvoice(Integer.parseInt(rs.getString("INVId")),Integer.parseInt(rs.getString("CompId")),Integer.parseInt(rs.getString("CustId")), LocalDate.parse(rs.getString("InvoiceDate")),Double.parseDouble(rs.getString("InvoiceAmount")),Double.parseDouble(rs.getString("InvoiceDiscount")),Double.parseDouble(rs.getString("InvoiceCGST")),Double.parseDouble(rs.getString("InvoiceSGST")),Double.parseDouble(rs.getString("InvoiceIGST")),Double.parseDouble(rs.getString("InvoiceGrandTotal")));
           }
            //System.out.println(finalInvoice.getInvoiceDate());
            setGUIData(finalInvoice);
           conn=DBConnections.getConnection();
           stmt=conn.prepareStatement("SELECT * from invoiceiteam NATURAL JOIN product where INVId=? order by ProductName");
           stmt.setString(1,getInvoiceNumber().toString());
           rs=stmt.executeQuery();
           while (rs.next())
           {
               invoiceProducts.add(new InvoiceProduct(Integer.parseInt(rs.getString("ProductId")),rs.getString("ProductName"),rs.getString("ProductUnit"),rs.getString("ProductHSNC"),Integer.parseInt(rs.getString("CompId")),Integer.parseInt(rs.getString("Quantity")),Double.parseDouble(rs.getString("Price"))));

           }

            ColumnInvoiceProductName.setCellValueFactory(new PropertyValueFactory<>("ProductName"));
           ColumnInvoiceProductHSNC.setCellValueFactory(new PropertyValueFactory<>("HSNC"));
        //   ColumnInvoiceProductQuantity.setCellValueFactory(new PropertyValueFactory<>("InvoiceProductQuantity"));
           ColumnInvoiceProductUnit.setCellValueFactory(new PropertyValueFactory<>("Unit"));
           ColumnInvoiceProductPrice.setCellValueFactory(new PropertyValueFactory<>("InvoiceProductPrice"));

            TableInvoiceProduct.setItems(invoiceProducts);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
