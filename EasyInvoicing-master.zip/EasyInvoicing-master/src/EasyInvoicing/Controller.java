package EasyInvoicing;

import com.jfoenix.controls.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    static public Company company;
    public void setCompany(EasyInvoicing.Company selectedItem) {
        company=selectedItem;
    }
    @FXML
    private AnchorPane Invoice;
    @FXML
    private AnchorPane Customer;
    @FXML
    private AnchorPane Product;
    @FXML
    private AnchorPane BillingInfo;
    @FXML
    private AnchorPane Settings;
    @FXML
    private AnchorPane addnewCustomer;

    @FXML
    private JFXButton ButtonGo;


    @FXML
    private JFXButton ButtonGo1;


    @FXML
    private AnchorPane Welcome;

    //Product Table code
    @FXML
    JFXButton SaveProduct;
    @FXML
    JFXTextField TextProductName;
    @FXML
    JFXTextField TextProductUnit;
    @FXML
    JFXTextField TextProductHSNC;
    @FXML
    private TableView<Product> ProductTable;
    private ObservableList<Product> products=FXCollections.observableArrayList();
    @FXML
    private TableColumn<Product,Long> ColumnProducatId;
    @FXML
    private TableColumn<Product,String> ColumnProductName;
    @FXML
    private TableColumn<Product,String> ColumnProductHSNC;
    @FXML
    private TableColumn<Product,String> ColumnProductUnit;

    private void ProductSet()  {

        Connection conn=DBConnections.getConnection();
        try {
            Statement stmt=conn.createStatement();
            PreparedStatement stm=conn.prepareStatement("select * from product where CompId=?");
            //System.out.println("Company id"+company.getCompId().toString());
            stm.setString(1,company.getCompId().toString());
            ResultSet rs=stm.executeQuery();
            //System.out.println("data");
            products.clear();
            while (rs.next()) {
                products.add(new Product(rs.getInt("ProductId"),rs.getString("ProductName"),rs.getString("ProductUnit"),rs.getString("ProductHSNC")));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        ColumnProducatId.setCellValueFactory(new PropertyValueFactory<>("ProductId"));
        ColumnProductName.setCellValueFactory(new PropertyValueFactory<>("ProductName"));
        ColumnProductUnit.setCellValueFactory(new PropertyValueFactory<>("Unit"));
        ColumnProductHSNC.setCellValueFactory(new PropertyValueFactory<>("HSNC"));
        ProductTable.setItems(products);

    }
    @FXML
    JFXButton btnProductDelete;
    @FXML
    void DeleteProduct(ActionEvent e) {

        Product p=ProductTable.getSelectionModel().getSelectedItem();
        Connection conn=DBConnections.getConnection();
        try {
            PreparedStatement stm = conn.prepareStatement("delete from product where ProductId=? and CompId=?");
            stm.setString(1, p.getProductId().toString());
            stm.setString(2, company.getCompId().toString());
            stm.executeUpdate();
            products.remove(p);
            AlertBox.display("Deleted","Product: "+p.getProductName()+"Has been Deleted");
        }
        catch (SQLException error)
        {
            AlertBox.display("Error",error.getMessage());
        }

        //AlertBox.display("Deleted","Succesfully Deleted");
        //Product is not Going to be Deleted because there is a Bill Which is connected with Selected Product
    }

    @FXML
    JFXButton btnProductUpdate;
    @FXML
    void UpdateProduct(ActionEvent e)  {

        Product p=ProductTable.getSelectionModel().getSelectedItem();
        Connection conn=DBConnections.getConnection();
        try {
            PreparedStatement stm = conn.prepareStatement("UPDATE product set ProductName=? ,ProductUnit=?,ProductHSNC=? where ProductId=? and CompId=?");
            stm.setString(1, TextProductName.getText().toString());
            stm.setString(2, TextProductUnit.getText().toString());
            stm.setString(3, TextProductHSNC.getText().toString());
            stm.setString(4, p.getProductId().toString());
            stm.setString(5, company.getCompId().toString());
            stm.executeUpdate();
            AlertBox.display("Updated", "Product: " + p.getProductName() + "Has Been Updated");
            Product newone = new Product(p.getProductId(), TextProductName.getText(), TextProductUnit.getText(), TextProductHSNC.getText(), p.getCompId());
            int index = products.indexOf(p);
            products.set(index, newone);
        }
        catch (SQLException error)
        {
            AlertBox.display("Error","Product: "+p.getProductName()+"Not Updated");
        }
    }

    @FXML
    void SaveProduct(ActionEvent e)  {

        boolean alert=false;
        String ProductName=TextProductName.getText().toString();
     //   System.out.println(ProductName);
        Connection conn=DBConnections.getConnection();
        try {
            PreparedStatement stmt = conn.prepareStatement("select ProductName from product where ProductName=? AND CompId=?");
            stmt.setString(1, ProductName);
            stmt.setString(2, company.getCompId().toString());
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                alert = true;
            }
            if (alert) {
                AlertBox.display("Error", "Product Already Exist");
            } else {

                new Queries().setProductData(new Product(0, TextProductName.getText().toString(), TextProductUnit.getText().toString(), TextProductHSNC.getText().toString()), company);
                AlertBox.display("SAVED", "Product is Saved");
            }
        }
        catch (SQLException Error)
        {
            AlertBox.display("Error", "Can not save this product to DATABASE for selecting reason");
        }
        ProductSet();

    }
    //Product Section END




    //Customer Section
    @FXML
    private TableView<Customer> CustomerTable;
    private ObservableList<Customer> customers=FXCollections.observableArrayList();
    @FXML
    private TableColumn<Customer,Integer> ColumnCustomerId;
    @FXML
    private TableColumn<Customer,String> ColumnCustomerName;
    @FXML
    private TableColumn<Customer,String> ColumnCustomerAddress;
    @FXML
    private TableColumn<Customer,String> ClCustGstTin;

    private void CustomerSet()
    {

        Connection conn=DBConnections.getConnection();
        try {
            Statement stmt=conn.createStatement();
            PreparedStatement stm=conn.prepareStatement("select * from customers where CompId=?");
            //System.out.println("Company id"+company.getCompId().toString());
            stm.setString(1,company.getCompId().toString());
            ResultSet rs=stm.executeQuery();
            //System.out.println("data");
            customers.clear();
            while (rs.next()) {
                customers.add(new Customer(rs.getInt("CustId"),rs.getString("CustName"),rs.getString("CustGstTin"),rs.getString("CustGstStateCode"),rs.getString("CustMobile"),rs.getString("CustAMobile"),rs.getString("CustAddress"),rs.getString("CustCity"),rs.getString("CustState"),rs.getString("CustZipCode"),rs.getInt("CompId")));
                //System.out.println(rs.getString("CustGstTin"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        ColumnCustomerId.setCellValueFactory(new PropertyValueFactory<>("CustId"));
        ColumnCustomerName.setCellValueFactory(new PropertyValueFactory<>("CustName"));
        ColumnCustomerAddress.setCellValueFactory(new PropertyValueFactory<>("CustAddress"));
        ClCustGstTin.setCellValueFactory(new PropertyValueFactory<>("CustGstTin"));
        CustomerTable.setItems(customers);
    }

    @FXML
    JFXButton SaveCustomer;


    @FXML
    JFXTextField TextCustName;
    @FXML
    JFXTextField TextCustAddress;
    @FXML
    JFXTextField TextCustCity;
    @FXML
    JFXTextField TextCustState;
    @FXML
    JFXTextField TextCustZipCode;
    @FXML
    JFXTextField TextCustCountry;
    @FXML
    JFXTextField TextCustGSTTin;
    @FXML
    JFXTextField TextCustGstStateCode;
    @FXML
    JFXTextField TextCustMobile;
    @FXML
    JFXTextField TextCustAMobile;
    @FXML
    void SaveCustomers(ActionEvent e)  {
        boolean alert=false;
        String CustName=TextCustName.getText().toString();
        Connection conn=DBConnections.getConnection();
        try {
            PreparedStatement stmt = conn.prepareStatement("select CustName from customers where CustName=? and CompId=?");
            stmt.setString(1, CustName);
            stmt.setString(2, company.getCompId().toString());
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                alert = true;
            }
            if (alert) {
                AlertBox.display("Error", "Customer Already Exist");
                //System.out.println("Customer Already Exist");
            } else {

                new Queries().setCustomerData(new Customer(0, TextCustName.getText().toString(), TextCustGSTTin.getText().toString(), TextCustGstStateCode.getText().toString(), TextCustMobile.getText().toString(), TextCustAMobile.getText().toString(), TextCustAddress.getText().toString(), TextCustCity.getText().toString(), TextCustState.getText().toString(), TextCustZipCode.getText().toString(), company.getCompId()), company);
                AlertBox.display("Saved", "Customer Data Stored ");
                Customer.setVisible(true);
                CustomerSet();
            }
        }
        catch (SQLException error)
        {
            AlertBox.display("Error", "Customer Cann't be added to DATABASE");
        }
        TextCustName.setText(" ");
        TextCustAddress.setText(" ");
        TextCustCity.setText(" ");
        TextCustState.setText(" ");
        TextCustZipCode.setText(" ");
        TextCustCountry.setText(" ");
        TextCustGSTTin.setText(" ");
        TextCustGstStateCode.setText(" ");
        TextCustMobile.setText(" ");
        TextCustAMobile.setText(" ");

    }




    @FXML
    void onGo(ActionEvent event)
    {
        company=CompanyTable.getSelectionModel().getSelectedItem();
    }




    //DashBoard Menu
    @FXML
    private JFXButton btnCustomer;
    @FXML
    private JFXButton btnProduct;
    @FXML
    private JFXButton btnInvoice;
    @FXML
    private JFXButton btnBillingInfo;
    @FXML
    private JFXButton btnSettings;
    @FXML
    private ImageView btnClose;
    @FXML
    private JFXButton btnaddProduct;
    @FXML
    private JFXButton btnaddCustomer;

    @FXML
    private void handleClose(MouseEvent event)
    {
        if(event.getSource() == btnClose)
        {
            System.exit(0);
        }
    }

    @FXML
    private void handleClick(MouseEvent event) throws SQLException {
        if(event.getSource()==btnCustomer)
        {
            Customer.setVisible(true);
            Product.setVisible(false);
            BillingInfo.setVisible(false);
            Invoice.setVisible(false);
            Settings.setVisible(false);
            Welcome.setVisible(false);
            CustomerSet();
        }
        else if(event.getSource()==btnProduct)
        {
            Customer.setVisible(false);
            Product.setVisible(true);
            BillingInfo.setVisible(false);
            Invoice.setVisible(false);
            Settings.setVisible(false);
            Welcome.setVisible(false);
            ProductSet();
        }
        else if(event.getSource()==btnBillingInfo)
        {
            Customer.setVisible(false);
            Product.setVisible(false);
            BillingInfo.setVisible(true);
            Invoice.setVisible(false);
            Settings.setVisible(false);
            setBillingInformationData();
        }
        else if(event.getSource()==btnInvoice)
        {
            Invoice.setVisible(true);
            Customer.setVisible(false);
            Product.setVisible(false);
            BillingInfo.setVisible(false);
            Settings.setVisible(false);
            Welcome.setVisible(false);
            setInvoice();
        }
        else if(event.getSource()==btnSettings)
        {
            Customer.setVisible(false);
            Product.setVisible(false);
            BillingInfo.setVisible(false);
            Invoice.setVisible(false);
            Settings.setVisible(true);
            Welcome.setVisible(false);
        }
        else if (event.getSource() == btnaddCustomer)
        {
            addnewCustomer.setVisible(true);
            Customer.setVisible(false);
            Product.setVisible(false);
            BillingInfo.setVisible(false);
            Invoice.setVisible(false);
            Settings.setVisible(false);
            Welcome.setVisible(false);
        }
        else if (event.getSource() == btnaddProduct)
        {
            addnewCustomer.setVisible(false);
            Customer.setVisible(false);
            Product.setVisible(false);
            BillingInfo.setVisible(false);
            Invoice.setVisible(false);
            Settings.setVisible(false);
            Welcome.setVisible(false);
        }
    }
    //DashBoard Ends

    //Invoice Section
    @FXML
    private JFXTextField InvoiceNumber;
    @FXML
    private JFXTextField InvoiceProductPrice;
    @FXML
    private JFXTextField InvoiceProductQuantity;
    @FXML
    private JFXTextField InvoiceAmount;
    @FXML
    private JFXTextField InvoiceCGST;
    @FXML
    private JFXTextField InvoiceSGST;
    @FXML
    private JFXTextField InvoiceDiscount;
    @FXML
    private JFXTextField InvoiceGrandTotal;
    @FXML
    private JFXDatePicker InvoiceDate;
    @FXML
    private JFXComboBox<Customer> CustomerCombobox;

    ObservableList<InvoiceProduct> InvoiceProducts=FXCollections.observableArrayList();
    @FXML
    ComboBox<EasyInvoicing.Product> ProductComboBox;
    @FXML
    TableView<InvoiceProduct> TableInvoiceProduct;
   /* @FXML
    TableColumn<InvoiceProduct,Integer> ColumnProductId;*/
    @FXML
    TableColumn<InvoiceProduct,String> ColumnInvoiceProductName;
    @FXML
    TableColumn<InvoiceProduct,String> ColumnInvoiceProductHSNC;
    @FXML
    TableColumn<InvoiceProduct,Integer> ColumnInvoiceProductQuantity;
    @FXML
    TableColumn<InvoiceProduct,String> ColumnInvoiceProductUnit;
    @FXML
    TableColumn<InvoiceProduct,Double> ColumnInvoiceProductPrice;
    //Init set Invoice Data
    private void setInvoice() throws SQLException {
        CustomerSet();
        ProductSet();
        Connection conn=DBConnections.getConnection();
        PreparedStatement ptm=conn.prepareStatement("select MAX(INVId) from invoice where CompId=?");
        ptm.setString(1,company.getCompId().toString());
        ResultSet rs=ptm.executeQuery();
        int Autoindex=0;

            while (rs.next()) {

                if (rs.wasNull()) {
                    Autoindex = 1;
                } else {
                    try {
                        Autoindex = Integer.parseInt(rs.getString("MAX(INVId)"))+1;
                    }
                    catch (Exception e)
                    {
                        Autoindex=1;
                    }
                }
            }

        InvoiceNumber.setText(String.valueOf(Autoindex));
        ColumnInvoiceProductName.setCellValueFactory(new PropertyValueFactory<>("ProductName"));
        ColumnProducatId.setCellValueFactory(new PropertyValueFactory<>("productId"));
        ColumnInvoiceProductHSNC.setCellValueFactory(new PropertyValueFactory<>("HSNC"));
        ColumnInvoiceProductQuantity.setCellValueFactory(new PropertyValueFactory<>("InvoiceProductQunatity"));
        ColumnInvoiceProductUnit.setCellValueFactory(new PropertyValueFactory<>("Unit"));
        ColumnInvoiceProductPrice.setCellValueFactory(new PropertyValueFactory<>("InvoiceProductPrice"));
        TableInvoiceProduct.setItems(InvoiceProducts);

        CustomerCombobox.setItems(customers);
        ProductComboBox.setItems(products);
        InvoiceAmount.setText(String.valueOf(0.0));
        InvoiceCGST.setText(String.valueOf(0.0));
        InvoiceSGST.setText(String.valueOf(0.0));
        InvoiceGrandTotal.setText(String.valueOf(0.0));
        InvoiceDiscount.setText(String.valueOf(0.0));
   }

    @FXML
    void  AddInvoiceProduct(ActionEvent e)
    {
        //System.out.println(ProductComboBox.getSelectionModel().getSelectedItem());
        Product p=ProductComboBox.getSelectionModel().getSelectedItem();
        //System.out.println(p.getProductName());
        InvoiceProducts.add(new InvoiceProduct(Integer.parseInt(p.getProductId().toString()),p.getProductName(),p.getUnit(),p.getHSNC(),p.getCompId(),Integer.parseInt(InvoiceProductQuantity.getText().toString()),Double.parseDouble(InvoiceProductPrice.getText().toString())*Double.parseDouble(InvoiceProductQuantity.getText().toString())));
        //Calculation Code

        Double sum=0.0;
        Customer InvoiceCustomer=CustomerCombobox.getSelectionModel().getSelectedItem();
        for (InvoiceProduct invoiceProduct:InvoiceProducts) {
            //System.out.println(invoiceProduct.getProductName());
            sum+=invoiceProduct.InvoiceProductPrice.doubleValue();
        }
        InvoiceAmount.setText(sum.toString());
        if(Double.parseDouble(InvoiceDiscount.getText().toString())>0.0)
        {
            sum=sum-(sum*Double.parseDouble(InvoiceDiscount.getText().toString()))/100;
            InvoiceAmount.setText(sum.toString());
        }
        double CGSTAmount=sum*Double.parseDouble(InvoiceCGST.getText().toString())/100;
        double SGSTAmount=sum*Double.parseDouble(InvoiceSGST.getText().toString())/100;
        double GrandTotal=CGSTAmount+SGSTAmount+sum;
        InvoiceGrandTotal.setText(String.valueOf(GrandTotal));

    }
    @FXML
    JFXButton btnDeleteInvoiceProduct;
    @FXML
    void DeleteInvoiceProduct(ActionEvent e)
    {
        InvoiceProduct delobject=TableInvoiceProduct.getSelectionModel().getSelectedItem();
        InvoiceProducts.remove(delobject);
        AlertBox.display("Deleted","Item Has been Deleted ");
        Double sum=0.0;
        Customer InvoiceCustomer=CustomerCombobox.getSelectionModel().getSelectedItem();
        for (InvoiceProduct invoiceProduct:InvoiceProducts) {
          //  System.out.println(invoiceProduct.getProductName());
            sum+=invoiceProduct.InvoiceProductPrice.doubleValue();
        }
        InvoiceAmount.setText(sum.toString());
        if(Double.parseDouble(InvoiceDiscount.getText().toString())>0.0)
        {
            sum=sum-(sum*Double.parseDouble(InvoiceDiscount.getText().toString()))/100;
            InvoiceAmount.setText(sum.toString());
        }
        double CGSTAmount=sum*Double.parseDouble(InvoiceCGST.getText().toString())/100;
        double SGSTAmount=sum*Double.parseDouble(InvoiceSGST.getText().toString())/100;
        double GrandTotal=CGSTAmount+SGSTAmount+sum;
        InvoiceGrandTotal.setText(String.valueOf(GrandTotal));
    }
    @FXML
    JFXButton btnUpdateInvoiceProduct;
    @FXML
    void UpdateInvoiceProduct(ActionEvent e)
    {
        InvoiceProduct selected=TableInvoiceProduct.getSelectionModel().getSelectedItem();
        int index=InvoiceProducts.indexOf(selected);
        Product p=ProductComboBox.getSelectionModel().getSelectedItem();
        InvoiceProducts.set(index,new InvoiceProduct(p.getProductId(),p.getProductName(),p.getUnit(),p.getHSNC(),p.getCompId(),Integer.parseInt(InvoiceProductQuantity.getText().toString()),Double.parseDouble(InvoiceProductPrice.getText().toString())*Double.parseDouble(InvoiceProductQuantity.getText().toString())));
        AlertBox.display("Updated","Item:"+selected.getProductName()+"Has been updated to "+p.getProductName());
        //Calculation Code
        Double sum=0.0;
        Customer InvoiceCustomer=CustomerCombobox.getSelectionModel().getSelectedItem();
        for (InvoiceProduct invoiceProduct:InvoiceProducts) {
          //  System.out.println(invoiceProduct.getProductName());
            sum+=invoiceProduct.InvoiceProductPrice.doubleValue();
        }
        InvoiceAmount.setText(sum.toString());
        if(Double.parseDouble(InvoiceDiscount.getText().toString())>0.0)
        {
            sum=sum-(sum*Double.parseDouble(InvoiceDiscount.getText().toString()))/100;
            InvoiceAmount.setText(sum.toString());
        }
        double CGSTAmount=sum*Double.parseDouble(InvoiceCGST.getText().toString())/100;
        double SGSTAmount=sum*Double.parseDouble(InvoiceSGST.getText().toString())/100;
        double GrandTotal=CGSTAmount+SGSTAmount+sum;
        InvoiceGrandTotal.setText(String.valueOf(GrandTotal));

    }

    @FXML
    JFXButton Invoicesave;
    @FXML
    void OnGo(ActionEvent e)
    {
        Connection conn=DBConnections.getConnection();
        //Calculation code
        Double sum=0.0;
        Customer InvoiceCustomer=CustomerCombobox.getSelectionModel().getSelectedItem();
        for (InvoiceProduct invoiceProduct:InvoiceProducts) {
          //  System.out.println(invoiceProduct.getProductName());
            sum+=invoiceProduct.InvoiceProductPrice.doubleValue();
        }
        InvoiceAmount.setText(sum.toString());
        if(Double.parseDouble(InvoiceDiscount.getText().toString())>0.0)
        {
            sum=sum-(sum*Double.parseDouble(InvoiceDiscount.getText().toString()))/100;
            InvoiceAmount.setText(sum.toString());
        }
        double CGSTAmount=sum*Double.parseDouble(InvoiceCGST.getText().toString())/100;
        double SGSTAmount=sum*Double.parseDouble(InvoiceSGST.getText().toString())/100;
        double GrandTotal=CGSTAmount+SGSTAmount+sum;
        InvoiceGrandTotal.setText(String.valueOf(GrandTotal));
        //calculation Code Ends Here

        FinalInvoice i=new FinalInvoice(Integer.parseInt(InvoiceNumber.getText()),company.CompId,InvoiceCustomer.CustId,InvoiceDate.getValue(),Double.parseDouble(InvoiceAmount.getText()),Double.parseDouble(InvoiceDiscount.getText()),Double.parseDouble(InvoiceCGST.getText()),Double.parseDouble(InvoiceSGST.getText()),0.0,Double.parseDouble(InvoiceGrandTotal.getText()));

        //System.out.println(Integer.parseInt(InvoiceNumber.getText())+company.CompId+InvoiceCustomer.CustId+InvoiceDate.getValue().toString()+Double.parseDouble(InvoiceAmount.getText())+Double.parseDouble(InvoiceDiscount.getText())+Double.parseDouble(InvoiceCGST.getText())+Double.parseDouble(InvoiceSGST.getText())+0.0+Double.parseDouble(InvoiceGrandTotal.getText()));
try {
    new Queries().setInvoiceData(i);
    for (InvoiceProduct invoiceProduct : InvoiceProducts) {
        PreparedStatement stmt = conn.prepareStatement("insert into invoiceiteam values (?,?,?,?)");
        stmt.setString(1, InvoiceNumber.getText().toString());
        stmt.setString(2, invoiceProduct.productId.toString());
        stmt.setString(3, invoiceProduct.InvoiceProductQunatity.toString());
        stmt.setString(4, invoiceProduct.InvoiceProductPrice.toString());
        stmt.executeUpdate();
        AlertBox.display("Saved","Invoice Has Been Saved");
        // sum+=invoiceProduct.InvoiceProductPrice.doubleValue();
    }
}
catch(SQLException Error)
{
    AlertBox.display("Error","Can't abel to save Invoice");
}
    }

    //Invoice Program Completed

    //Companyset
    private void CompanySet()  {

        Connection conn=DBConnections.getConnection();
        try {
            Statement stmt=conn.createStatement();
            ResultSet rs=stmt.executeQuery("select CompId,CompName from company");
         //   System.out.println("data");
            companies.clear();
            while (rs.next()) {
                companies.add(new Company(rs.getInt("CompID"), rs.getString("CompName")));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        TableName.setCellValueFactory(new PropertyValueFactory<>("CompName"));
        CompanyTable.setItems(companies);
    }


    //Billing Information Section
    //Start
    @FXML
    TableView<BillingInformation> TableBillingInformation;
    @FXML
    TableColumn<BillingInformation,Integer> ColumnINVId;
    @FXML
    TableColumn<BillingInformation,String> ColumnCustName;
    @FXML
    TableColumn<BillingInformation, LocalDate> ColumnInvoiceDate;
    @FXML
    TableColumn<BillingInformation,Double> ColumnAmount;
    ObservableList<BillingInformation> billingInformations=FXCollections.observableArrayList();

    void setBillingInformationData() throws SQLException {
        billingInformations.clear();
        Connection conn=DBConnections.getConnection();
        PreparedStatement stmt=conn.prepareStatement("SELECT invoice.INVId as a,customers.CustName,invoice.InvoiceDate,invoice.InvoiceGrandTotal FROM invoice NATURAL JOIN customers where CompId=?");
        stmt.setString(1,company.getCompId().toString());
        ResultSet rs=stmt.executeQuery();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-M-yyyy");
        while (rs.next())
        {
            //System.out.println(formatter.format(LocalDate.parse(rs.getString("InvoiceDate"),formatter)));
            String localDate=LocalDate.parse(rs.getString("InvoiceDate")).format(formatter);
         billingInformations.add(new BillingInformation(Integer.parseInt(rs.getString("a")),rs.getString("CustName"),LocalDate.parse(rs.getString("InvoiceDate")).format(formatter),Double.parseDouble(rs.getString("InvoiceGrandTotal"))));
        }
        ColumnINVId.setCellValueFactory(new PropertyValueFactory<>("INVId"));
        ColumnCustName.setCellValueFactory(new PropertyValueFactory<>("CustName"));
        ColumnInvoiceDate.setCellValueFactory(new PropertyValueFactory<>("InvoiceDate"));
        ColumnAmount.setCellValueFactory(new PropertyValueFactory<>("Amount"));
        TableBillingInformation.setItems(billingInformations);
    }


    @FXML
    JFXButton DeleteBill;
    @FXML
    void DeleteBill(ActionEvent e)  {
        BillingInformation deleteBill=TableBillingInformation.getSelectionModel().getSelectedItem();
        Connection conn=DBConnections.getConnection();
        try {
            PreparedStatement stmt = conn.prepareStatement("delete from invoiceiteam where INVId=?");
            stmt.setString(1, deleteBill.getINVId().toString());
            stmt.executeUpdate();
            stmt = conn.prepareStatement("delete from invoice where INVId=?");
            stmt.setString(1, deleteBill.getINVId().toString());
            stmt.executeUpdate();
            billingInformations.remove(deleteBill);
            AlertBox.display("Delete", "Selected Bill with Invoice Number"+deleteBill.getINVId()+"Has been Deleted");
        }
        catch (SQLException error)
        {
            AlertBox.display("Error", "Can't able to delete bill");
        }
    }

    @FXML
    JFXButton openBill;
    @FXML
    void SelectBill(ActionEvent e) throws IOException {
        if (TableBillingInformation.getSelectionModel().isEmpty())
        {
            AlertBox.display("Error","Please select bill first");
        }
        else {
            new EasyInvoicing.BillingInfoC().setInvoiceData(TableBillingInformation.getSelectionModel().getSelectedItem().getINVId(), company.getCompId());
            Parent rroot;
            rroot = FXMLLoader.load(getClass().getResource("BillingInfo.fxml"));
            Stage stage = new Stage();
            stage.setTitle("Check Bill");
            stage.setScene(new Scene(rroot, 1280, 720));
            stage.show();
        }
    }
    //Billing Information Section END

    @FXML
    private TableView<EasyInvoicing.Company> CompanyTable;
    @FXML
    private TableColumn<Company,String> TableName;
    private ObservableList<Company> companies = FXCollections.observableArrayList();


    @Override
    public void initialize(URL location, ResourceBundle resources) {

        //CustomerSet();

    }
}
