package EasyInvoicing;

public class InvoiceProduct {
    Integer productId;
    private   String ProductName;
    String Unit;
    String HSNC;
    Integer CompId;
    Integer InvoiceProductQunatity;
    Double InvoiceProductPrice;


    public InvoiceProduct(Integer productId, String productName, String unit, String HSNC, Integer compId, Integer invoiceProductQunatity, Double invoiceProductPrice) {
      //  System.out.println(productId);
        this.productId = productId;
        ProductName = productName;
        Unit = unit;
        this.HSNC = HSNC;
        CompId = compId;
        InvoiceProductQunatity = invoiceProductQunatity;
        InvoiceProductPrice = invoiceProductPrice;
    }
/*
    public InvoiceProduct(Product p, Integer invoiceProductQunatity, Double invoiceProductPrice) {
        super(p);
        InvoiceProductQunatity = invoiceProductQunatity;
        InvoiceProductPrice = invoiceProductPrice;
    }*/

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String productName) {
        ProductName = productName;
    }

    public String getUnit() {
        return Unit;
    }

    public void setUnit(String unit) {
        Unit = unit;
    }

    public String getHSNC() {
        return HSNC;
    }

    public void setHSNC(String HSNC) {
        this.HSNC = HSNC;
    }

    public Integer getCompId() {
        return CompId;
    }

    public void setCompId(Integer compId) {
        CompId = compId;
    }

    public Integer getInvoiceProductQunatity() {
        return InvoiceProductQunatity;
    }

    public void setInvoiceProductQunatity(Integer invoiceProductQunatity) {
        InvoiceProductQunatity = invoiceProductQunatity;
    }

    public Double getInvoiceProductPrice() {
        return InvoiceProductPrice;
    }

    public void setInvoiceProductPrice(Double invoiceProductPrice) {
        InvoiceProductPrice = invoiceProductPrice;
    }
}
