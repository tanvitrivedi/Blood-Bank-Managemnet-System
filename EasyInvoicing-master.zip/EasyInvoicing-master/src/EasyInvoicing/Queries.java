package EasyInvoicing;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class Queries {
    public void setCompanyData(Company o) throws SQLException
    {
        Connection conn=DBConnections.getConnection();
        PreparedStatement stmt=conn.prepareStatement("insert into company values( null,?,?,?,?,?,?,?,?,?,?,?,?,null,null)");
        stmt.setString(1,o.getCompName());
        stmt.setString(2,o.CompAddress);
        stmt.setString(3,o.CompCity);
        stmt.setString(4,o.CompState);
        stmt.setString(5,o.CompZipCode);
        stmt.setString(6,o.CompCountry);
        stmt.setString(7,o.CompGSTTin);
        stmt.setString(8,o.CompGSTStateCode);
        stmt.setString(9,o.CompBankAcNo);
        stmt.setString(10,o.CompBankName);
        stmt.setString(11,o.CompBankBranch);
        stmt.setString(12,o.CompBankIFSC);
        stmt.executeUpdate();
    }

    void setCustomerData(Customer cust,Company referece) throws SQLException
    {
        Connection conn=DBConnections.getConnection();
        PreparedStatement stmt=conn.prepareStatement("insert into customers values( null,?,?,?,?,?,?,?,?,?,?)");
        stmt.setString(1,cust.CustName);
        stmt.setString(2,cust.CustGstTin);
        //System.out.println(cust.CustGstTin);
        stmt.setString(3,cust.CustGstStateCode);
        stmt.setString(4,cust.CustMobile);
        stmt.setString(5,cust.CustAMobile);
        stmt.setString(6,cust.CustAddress);
        stmt.setString(7,cust.CustCity);
        stmt.setString(8,cust.CustState);
        stmt.setString(9,cust.CustZipCode);
        //System.out.println(referece.getCompId().toString());
        stmt.setString(10,referece.getCompId().toString());
        stmt.executeUpdate();
    }

    void setProductData(Product product,Company reference) throws SQLException {
        Connection conn=DBConnections.getConnection();
        PreparedStatement stmt=conn.prepareStatement("insert into product values(null ,?,?,?,?)");
        stmt.setString(1,product.getProductName());
        stmt.setString(2,product.getUnit());
        stmt.setString(3,product.getHSNC());
        System.out.println("setiing company id "+reference.getCompId().toString());
        stmt.setString(4,reference.getCompId().toString());
        stmt.executeUpdate();
    }
    void setInvoiceData(FinalInvoice i) throws SQLException {
        Connection conn=DBConnections.getConnection();
        PreparedStatement stmt=conn.prepareStatement("INSERT INTO  invoice VALUES ( ? , ?, ?, ?, ?, ?, ?, ?, ?, ?, 0);");
        stmt.setString(1,i.InvoiceNumber.toString());
        stmt.setString(2,i.CompId.toString());
        stmt.setString(3,i.CustId.toString());
        //stmt.setString(4,i.InvoiceDate.toString());
            stmt.setString(4,i.InvoiceDate.toString());
        stmt.setString(5,i.InvoiceAmount.toString());
        stmt.setString(6,i.InvoiceDiscount.toString());
        stmt.setString(7,i.InvoiceCGST.toString());
        stmt.setString(8,i.InvoiceSGST.toString());
        stmt.setString(9,i.InvoiceIGST.toString());
        stmt.setString(10,i.InvoiceGrandTotal.toString());
        stmt.executeUpdate();
    }
    public FinalInvoice getFinalInvoice(Integer INVId,Integer CompId) throws SQLException {
        Connection conn=DBConnections.getConnection();
        FinalInvoice finalI=null;
        PreparedStatement stmt=conn.prepareStatement("select * from invoice where INVId=? and CompId=?");
        stmt.setString(1,INVId.toString());
        stmt.setString(2,CompId.toString());
        ResultSet rs=stmt.executeQuery();
        while (rs.next())
        {
            finalI=new FinalInvoice(Integer.parseInt(rs.getString("INVId")),Integer.parseInt(rs.getString("CompId")),Integer.parseInt(rs.getString("CustId")), LocalDate.parse(rs.getString("InvoiceDate")),Double.parseDouble(rs.getString("InvoiceAmount")),Double.parseDouble(rs.getString("InvoiceDiscount")),Double.parseDouble(rs.getString("InvoiceCGST")),Double.parseDouble(rs.getString("InvoiceSGST")),Double.parseDouble(rs.getString("InvoiceIGST")),Double.parseDouble(rs.getString("InvoiceGrandTotal")));
        }
        //System.out.println(tempFinalInvoice);
        return finalI;
    }
}
