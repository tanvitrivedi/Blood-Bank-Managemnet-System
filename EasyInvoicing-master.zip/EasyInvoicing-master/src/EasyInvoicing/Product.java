package EasyInvoicing;

public class Product {
     Integer ProductId;
     String ProductName;
     String Unit;
     String HSNC;
     Integer CompId;

    public Product() {
    }
    public Product(Product p)
    {
        this(p.ProductId, p.ProductName, p.Unit, p.HSNC, p.CompId);
    }

    @Override
    public String toString() {
        return ProductName;
    }

    public Product(Integer productId, String productName, String unit, String HSNC) {
        ProductId = productId;
        ProductName = productName;
        Unit = unit;
        this.HSNC = HSNC;
    }

    public Product(Integer productId, String productName, String unit, String HSNC, Integer compId) {
        ProductId = productId;
        ProductName = productName;
        Unit = unit;
        this.HSNC = HSNC;
        CompId = compId;
    }

    public Integer getCompId() {
        return CompId;
    }

    public void setCompId(int compId) {
        CompId = compId;
    }

    public Integer getProductId() {
        return ProductId;
    }

    public void setProductId(Integer productId) {
        ProductId = productId;
    }

    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String productName) {
        ProductName = productName;
    }

    public String getUnit() {
        return Unit;
    }

    public void setUnit(String unit) {
        Unit = unit;
    }

    public String getHSNC() {
        return HSNC;
    }

    public void setHSNC(String HSNC) {
        this.HSNC = HSNC;
    }
}
